#import "FilterEngine.h"

#import <CoreGraphics/CoreGraphics.h>
#import <UIKit/UIKit.h>
#import <simd/simd.h>

#include <atomic>

#include "ShadersEmbedded.inc"

typedef struct {
    vector_float4 effectA;
    vector_float4 effectB;
    vector_float4 yuvRange;
    vector_uint4 meta;
} VFGPUUniforms;

typedef struct {
    vector_float4 params;
} VFPresentUniforms;

static inline float VFClampF(float x, float lo, float hi) {
    return fminf(fmaxf(x, lo), hi);
}

static inline BOOL VFCFStringEqual(CFTypeRef value, CFStringRef expected) {
    return value && expected && CFGetTypeID(value) == CFStringGetTypeID() && CFEqual(value, expected);
}

@interface FilterEngine ()
@property (nonatomic, readwrite) BOOL lastFrameWasSupported;
@end

@implementation FilterEngine {
    __weak CAMetalLayer *_metalLayer;
    id<MTLDevice> _device;
    id<MTLCommandQueue> _commandQueue;
    id<MTLLibrary> _library;
    id<MTLComputePipelineState> _yuvPipeline;
    id<MTLComputePipelineState> _bgraPipeline;
    id<MTLComputePipelineState> _basicPipeline;
    id<MTLComputePipelineState> _sharpenPipeline;
    id<MTLComputePipelineState> _temporalPipeline;
    id<MTLComputePipelineState> _sceneCutPipeline;
    id<MTLRenderPipelineState> _presentPipeline;
    CVMetalTextureCacheRef _textureCache;

    id<MTLTexture> _textureA;
    id<MTLTexture> _textureB;
    id<MTLTexture> _previousTexture;
    NSUInteger _textureWidth;
    NSUInteger _textureHeight;
    NSInteger _lastColorPrimariesCode;
    BOOL _previousValid;
    CMTime _lastItemTime;

    NSArray<id<MTLBuffer>> *_sceneCutBuffers;
    NSUInteger _sceneCutBufferIndex;
    dispatch_semaphore_t _inFlightSemaphore;
    std::atomic_bool _sceneCutPending;
    std::atomic_bool _invalidated;

#if DEBUG
    CFTimeInterval _debugWindowStart;
    NSUInteger _debugFrameCount;
#endif
}

@synthesize device = _device;

- (instancetype)initWithMetalLayer:(CAMetalLayer *)metalLayer {
    self = [super init];
    if (!self) return nil;

    _metalLayer = metalLayer;
    _settings = VFFilterPresetDefaults();
    _videoGravity = AVLayerVideoGravityResizeAspect;
    _lastItemTime = kCMTimeInvalid;
    _lastColorPrimariesCode = -1;
    _sceneCutPending.store(false);
    _invalidated.store(false);
    self.lastFrameWasSupported = NO;

    _device = MTLCreateSystemDefaultDevice();
    if (!_device) return nil;
    _commandQueue = [_device newCommandQueue];
    if (!_commandQueue) return nil;

    metalLayer.device = _device;
    metalLayer.pixelFormat = MTLPixelFormatRGBA16Float;
    metalLayer.framebufferOnly = YES;
    metalLayer.opaque = NO;
    metalLayer.allowsEdgeAntialiasing = NO;
    if ([metalLayer respondsToSelector:@selector(setWantsExtendedDynamicRangeContent:)]) {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunguarded-availability-new"
        metalLayer.wantsExtendedDynamicRangeContent = YES;
#pragma clang diagnostic pop
    }
    [self setMetalLayerColorSpaceName:kCGColorSpaceExtendedLinearSRGB];

    NSError *error = nil;
    MTLCompileOptions *options = [MTLCompileOptions new];
    _library = [_device newLibraryWithSource:[NSString stringWithUTF8String:kVFMetalShaderSource]
                                    options:options
                                      error:&error];
    if (!_library) {
        NSLog(@"[VideoFilter] Metal source compile failed: %@", error);
        return nil;
    }

#define VF_MAKE_COMPUTE(ivar, name) do { \
    id<MTLFunction> fn = [_library newFunctionWithName:@name]; \
    if (!fn) { NSLog(@"[VideoFilter] Missing Metal function %s", name); return nil; } \
    NSError *pipelineError = nil; \
    ivar = [_device newComputePipelineStateWithFunction:fn error:&pipelineError]; \
    if (!ivar) { NSLog(@"[VideoFilter] Pipeline %s failed: %@", name, pipelineError); return nil; } \
} while (0)

    VF_MAKE_COMPUTE(_yuvPipeline, "vfYUVToLinear");
    VF_MAKE_COMPUTE(_bgraPipeline, "vfBGRAToLinear");
    VF_MAKE_COMPUTE(_basicPipeline, "vfBasicAdjust");
    VF_MAKE_COMPUTE(_sharpenPipeline, "vfSharpen");
    VF_MAKE_COMPUTE(_temporalPipeline, "vfTemporalBlend");
    VF_MAKE_COMPUTE(_sceneCutPipeline, "vfSceneCutDetect");
#undef VF_MAKE_COMPUTE

    id<MTLFunction> vertex = [_library newFunctionWithName:@"vfPresentVertex"];
    id<MTLFunction> fragment = [_library newFunctionWithName:@"vfPresentFragment"];
    if (!vertex || !fragment) return nil;

    MTLRenderPipelineDescriptor *renderDesc = [MTLRenderPipelineDescriptor new];
    renderDesc.vertexFunction = vertex;
    renderDesc.fragmentFunction = fragment;
    renderDesc.colorAttachments[0].pixelFormat = MTLPixelFormatRGBA16Float;
    renderDesc.colorAttachments[0].blendingEnabled = YES;
    renderDesc.colorAttachments[0].sourceRGBBlendFactor = MTLBlendFactorSourceAlpha;
    renderDesc.colorAttachments[0].destinationRGBBlendFactor = MTLBlendFactorOneMinusSourceAlpha;
    renderDesc.colorAttachments[0].sourceAlphaBlendFactor = MTLBlendFactorOne;
    renderDesc.colorAttachments[0].destinationAlphaBlendFactor = MTLBlendFactorOneMinusSourceAlpha;
    _presentPipeline = [_device newRenderPipelineStateWithDescriptor:renderDesc error:&error];
    if (!_presentPipeline) {
        NSLog(@"[VideoFilter] Present pipeline failed: %@", error);
        return nil;
    }

    CVReturn cacheResult = CVMetalTextureCacheCreate(kCFAllocatorDefault, NULL, _device, NULL, &_textureCache);
    if (cacheResult != kCVReturnSuccess || !_textureCache) {
        NSLog(@"[VideoFilter] CVMetalTextureCacheCreate failed: %d", cacheResult);
        return nil;
    }

    NSMutableArray<id<MTLBuffer>> *sceneBuffers = [NSMutableArray arrayWithCapacity:3];
    for (NSUInteger i = 0; i < 3; i++) {
        id<MTLBuffer> buffer = [_device newBufferWithLength:sizeof(uint32_t)
                                                    options:MTLResourceStorageModeShared];
        if (!buffer) return nil;
        [sceneBuffers addObject:buffer];
    }
    _sceneCutBuffers = [sceneBuffers copy];
    _inFlightSemaphore = dispatch_semaphore_create(3);

#if DEBUG
    _debugWindowStart = CACurrentMediaTime();
    _debugFrameCount = 0;
#endif
    return self;
}

- (void)dealloc {
    _invalidated.store(true);
    if (_textureCache) {
        CVMetalTextureCacheFlush(_textureCache, 0);
        CFRelease(_textureCache);
        _textureCache = NULL;
    }
}

- (void)setMetalLayerColorSpaceName:(CFStringRef)name {
    CAMetalLayer *layer = _metalLayer;
    if (!layer || !name) return;
    CGColorSpaceRef colorSpace = CGColorSpaceCreateWithName(name);
    if (colorSpace) {
        layer.colorspace = colorSpace;
        CGColorSpaceRelease(colorSpace);
    }
}

- (void)setSettings:(VFFilterSettings)settings {
    _settings = settings;
    if (!settings.enabled || settings.motionBlur <= 0.0001f) {
        [self resetTemporalHistory];
    }
}

- (void)resetTemporalHistory {
    _previousValid = NO;
    _lastItemTime = kCMTimeInvalid;
    _lastColorPrimariesCode = -1;
    _sceneCutPending.store(false);
}

- (void)purgeReusableResources {
    [self resetTemporalHistory];
    _textureA = nil;
    _textureB = nil;
    _previousTexture = nil;
    _textureWidth = 0;
    _textureHeight = 0;
    if (_textureCache) CVMetalTextureCacheFlush(_textureCache, 0);
}

- (BOOL)ensureWorkingTexturesWidth:(NSUInteger)width height:(NSUInteger)height {
    if (width == 0 || height == 0) return NO;
    if (_textureA && _textureWidth == width && _textureHeight == height) return YES;

    _textureWidth = width;
    _textureHeight = height;
    _previousValid = NO;

    MTLTextureDescriptor *desc = [MTLTextureDescriptor texture2DDescriptorWithPixelFormat:MTLPixelFormatRGBA16Float
                                                                                    width:width
                                                                                   height:height
                                                                                mipmapped:NO];
    desc.usage = MTLTextureUsageShaderRead | MTLTextureUsageShaderWrite;
    desc.storageMode = MTLStorageModePrivate;
    _textureA = [_device newTextureWithDescriptor:desc];
    _textureB = [_device newTextureWithDescriptor:desc];
    _previousTexture = [_device newTextureWithDescriptor:desc];
    return _textureA && _textureB && _previousTexture;
}

- (NSUInteger)transferFunctionForPixelBuffer:(CVPixelBufferRef)pixelBuffer isHDR:(BOOL *)isHDR {
    if (isHDR) *isHDR = NO;
    CFTypeRef tf = CVBufferGetAttachment(pixelBuffer, kCVImageBufferTransferFunctionKey, NULL);
    if (VFCFStringEqual(tf, kCVImageBufferTransferFunction_sRGB)) return 1;
    if (VFCFStringEqual(tf, kCVImageBufferTransferFunction_SMPTE_ST_2084_PQ)) {
        if (isHDR) *isHDR = YES;
        return 2;
    }
    if (VFCFStringEqual(tf, kCVImageBufferTransferFunction_ITU_R_2100_HLG)) {
        if (isHDR) *isHDR = YES;
        return 3;
    }
    // BT.709 and BT.2020 SDR use the 709-style transfer here.
    return 0;
}

- (NSUInteger)yuvMatrixForPixelBuffer:(CVPixelBufferRef)pixelBuffer {
    CFTypeRef matrix = CVBufferGetAttachment(pixelBuffer, kCVImageBufferYCbCrMatrixKey, NULL);
    if (VFCFStringEqual(matrix, kCVImageBufferYCbCrMatrix_ITU_R_601_4)) return 0;
    if (VFCFStringEqual(matrix, kCVImageBufferYCbCrMatrix_ITU_R_2020)) return 2;
    return 1;
}

- (void)updateOutputColorSpaceForPixelBuffer:(CVPixelBufferRef)pixelBuffer {
    CFTypeRef primaries = CVBufferGetAttachment(pixelBuffer, kCVImageBufferColorPrimariesKey, NULL);
    NSInteger code = 0; // sRGB/BT.709 primaries
    if (VFCFStringEqual(primaries, kCVImageBufferColorPrimaries_P3_D65)) code = 1;
    else if (VFCFStringEqual(primaries, kCVImageBufferColorPrimaries_ITU_R_2020)) code = 2;
    if (code == _lastColorPrimariesCode) return;
    _lastColorPrimariesCode = code;

    if (code == 2) {
        [self setMetalLayerColorSpaceName:kCGColorSpaceExtendedLinearITUR_2020];
    } else if (code == 1) {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
        [self setMetalLayerColorSpaceName:kCGColorSpaceExtendedLinearDisplayP3];
#pragma clang diagnostic pop
    } else {
        [self setMetalLayerColorSpaceName:kCGColorSpaceExtendedLinearSRGB];
    }
}

- (VFGPUUniforms)uniformsForPixelBuffer:(CVPixelBufferRef)pixelBuffer
                              fullRange:(BOOL)fullRange
                               tenBit:(BOOL)tenBit {
    VFFilterSettings s = self.settings;
    VFGPUUniforms u = {};

    float normalizedContrast = VFClampF(s.contrast / 100.0f, -1.0f, 1.0f);
    float contrastFactor = normalizedContrast >= 0.0f
        ? 1.0f + 0.80f * normalizedContrast
        : 1.0f + 0.65f * normalizedContrast;
    float saturationFactor = VFClampF(1.0f + s.saturation / 100.0f, 0.0f, 2.0f);
    float exposureStops = VFClampF(s.exposure / 100.0f, -1.0f, 1.0f) * 2.0f;
    float highlightStrength = VFClampF(s.highlights / 100.0f, -1.0f, 1.0f) * 0.55f;
    float sharpenAmount = VFClampF(s.sharpen / 100.0f, 0.0f, 1.0f) * 1.20f;
    float motionBlend = VFClampF(s.motionBlur / 100.0f, 0.0f, 0.20f);

    u.effectA = (vector_float4){ exposureStops, contrastFactor, saturationFactor, highlightStrength };
    u.effectB = (vector_float4){ sharpenAmount, motionBlend,
        1.0f / MAX((float)_textureWidth, 1.0f), 1.0f / MAX((float)_textureHeight, 1.0f) };

    if (fullRange) {
        u.yuvRange = (vector_float4){ 0.0f, 1.0f, 0.5f, 1.0f };
    } else if (tenBit) {
        u.yuvRange = (vector_float4){ 64.0f / 1023.0f, 1023.0f / 876.0f,
                                      512.0f / 1023.0f, 1023.0f / 896.0f };
    } else {
        u.yuvRange = (vector_float4){ 16.0f / 255.0f, 255.0f / 219.0f,
                                      128.0f / 255.0f, 255.0f / 224.0f };
    }

    BOOL hdr = NO;
    NSUInteger transfer = [self transferFunctionForPixelBuffer:pixelBuffer isHDR:&hdr];
    u.meta = (vector_uint4){ (uint32_t)[self yuvMatrixForPixelBuffer:pixelBuffer],
                             (uint32_t)transfer,
                             hdr ? 1u : 0u,
                             tenBit ? 10u : 8u };
    return u;
}

- (BOOL)makeInputTexturesForPixelBuffer:(CVPixelBufferRef)pixelBuffer
                              yTexture:(id<MTLTexture> __autoreleasing *)yTexture
                             uvTexture:(id<MTLTexture> __autoreleasing *)uvTexture
                           bgraTexture:(id<MTLTexture> __autoreleasing *)bgraTexture
                             fullRange:(BOOL *)fullRange
                                tenBit:(BOOL *)tenBit {
    if (yTexture) *yTexture = nil;
    if (uvTexture) *uvTexture = nil;
    if (bgraTexture) *bgraTexture = nil;
    if (fullRange) *fullRange = NO;
    if (tenBit) *tenBit = NO;

    OSType format = CVPixelBufferGetPixelFormatType(pixelBuffer);
    size_t width = CVPixelBufferGetWidth(pixelBuffer);
    size_t height = CVPixelBufferGetHeight(pixelBuffer);

    if (format == kCVPixelFormatType_32BGRA) {
        CVMetalTextureRef ref = NULL;
        CVReturn r = CVMetalTextureCacheCreateTextureFromImage(kCFAllocatorDefault, _textureCache,
            pixelBuffer, NULL, MTLPixelFormatBGRA8Unorm, width, height, 0, &ref);
        if (r != kCVReturnSuccess || !ref) return NO;
        id<MTLTexture> texture = CVMetalTextureGetTexture(ref);
        if (bgraTexture) *bgraTexture = texture;
        CFRelease(ref);
        return texture != nil;
    }

    BOOL is8Video = (format == kCVPixelFormatType_420YpCbCr8BiPlanarVideoRange);
    BOOL is8Full = (format == kCVPixelFormatType_420YpCbCr8BiPlanarFullRange);
    BOOL is10Video = (format == kCVPixelFormatType_420YpCbCr10BiPlanarVideoRange);
    BOOL is10Full = (format == kCVPixelFormatType_420YpCbCr10BiPlanarFullRange);
    if (!is8Video && !is8Full && !is10Video && !is10Full) return NO;
    if (CVPixelBufferGetPlaneCount(pixelBuffer) < 2) return NO;

    BOOL ten = is10Video || is10Full;
    BOOL full = is8Full || is10Full;
    MTLPixelFormat yFormat = ten ? MTLPixelFormatR16Unorm : MTLPixelFormatR8Unorm;
    MTLPixelFormat uvFormat = ten ? MTLPixelFormatRG16Unorm : MTLPixelFormatRG8Unorm;
    size_t yWidth = CVPixelBufferGetWidthOfPlane(pixelBuffer, 0);
    size_t yHeight = CVPixelBufferGetHeightOfPlane(pixelBuffer, 0);
    size_t uvWidth = CVPixelBufferGetWidthOfPlane(pixelBuffer, 1);
    size_t uvHeight = CVPixelBufferGetHeightOfPlane(pixelBuffer, 1);

    CVMetalTextureRef yRef = NULL;
    CVMetalTextureRef uvRef = NULL;
    CVReturn yr = CVMetalTextureCacheCreateTextureFromImage(kCFAllocatorDefault, _textureCache,
        pixelBuffer, NULL, yFormat, yWidth, yHeight, 0, &yRef);
    CVReturn uvr = CVMetalTextureCacheCreateTextureFromImage(kCFAllocatorDefault, _textureCache,
        pixelBuffer, NULL, uvFormat, uvWidth, uvHeight, 1, &uvRef);
    if (yr != kCVReturnSuccess || uvr != kCVReturnSuccess || !yRef || !uvRef) {
        if (yRef) CFRelease(yRef);
        if (uvRef) CFRelease(uvRef);
        return NO;
    }

    id<MTLTexture> y = CVMetalTextureGetTexture(yRef);
    id<MTLTexture> uv = CVMetalTextureGetTexture(uvRef);
    if (yTexture) *yTexture = y;
    if (uvTexture) *uvTexture = uv;
    if (fullRange) *fullRange = full;
    if (tenBit) *tenBit = ten;
    CFRelease(yRef);
    CFRelease(uvRef);
    return y && uv;
}

- (void)dispatchPipeline:(id<MTLComputePipelineState>)pipeline
                 encoder:(id<MTLComputeCommandEncoder>)encoder
                   width:(NSUInteger)width
                  height:(NSUInteger)height {
    NSUInteger tw = pipeline.threadExecutionWidth;
    NSUInteger th = MAX(1, pipeline.maxTotalThreadsPerThreadgroup / MAX(tw, 1));
    th = MIN(th, 16);
    MTLSize threads = MTLSizeMake(tw, th, 1);
    MTLSize grid = MTLSizeMake(width, height, 1);
    [encoder dispatchThreads:grid threadsPerThreadgroup:threads];
}

- (void)encodePresentTexture:(id<MTLTexture>)source
               commandBuffer:(id<MTLCommandBuffer>)commandBuffer
                    drawable:(id<CAMetalDrawable>)drawable {
    if (!source || !drawable) return;
    MTLRenderPassDescriptor *pass = [MTLRenderPassDescriptor renderPassDescriptor];
    pass.colorAttachments[0].texture = drawable.texture;
    pass.colorAttachments[0].loadAction = MTLLoadActionClear;
    pass.colorAttachments[0].storeAction = MTLStoreActionStore;
    pass.colorAttachments[0].clearColor = MTLClearColorMake(0, 0, 0, 0);

    id<MTLRenderCommandEncoder> render = [commandBuffer renderCommandEncoderWithDescriptor:pass];
    [render setRenderPipelineState:_presentPipeline];
    [render setFragmentTexture:source atIndex:0];

    float videoAspect = (float)source.width / MAX((float)source.height, 1.0f);
    float drawAspect = (float)drawable.texture.width / MAX((float)drawable.texture.height, 1.0f);
    float gravity = 1.0f;
    if ([self.videoGravity isEqualToString:AVLayerVideoGravityResize]) gravity = 0.0f;
    else if ([self.videoGravity isEqualToString:AVLayerVideoGravityResizeAspectFill]) gravity = 2.0f;
    VFPresentUniforms p;
    p.params = (vector_float4){ videoAspect, drawAspect, gravity, 0.0f };
    [render setFragmentBytes:&p length:sizeof(p) atIndex:0];
    [render drawPrimitives:MTLPrimitiveTypeTriangle vertexStart:0 vertexCount:3];
    [render endEncoding];
}

- (BOOL)renderPixelBuffer:(CVPixelBufferRef)pixelBuffer itemTime:(CMTime)itemTime {
    if (!pixelBuffer || !_device || !_commandQueue || !_textureCache) return NO;
    CAMetalLayer *layer = _metalLayer;
    if (!layer || self.settings.enabled == NO) return NO;

    NSUInteger width = CVPixelBufferGetWidth(pixelBuffer);
    NSUInteger height = CVPixelBufferGetHeight(pixelBuffer);
    if (![self ensureWorkingTexturesWidth:width height:height]) return NO;

    // Temporal history is invalid after seeks, backward jumps, long discontinuities,
    // or a scene cut flagged by the prior frame's asynchronous detector.
    if (_sceneCutPending.exchange(false)) _previousValid = NO;
    if (CMTIME_IS_NUMERIC(_lastItemTime) && CMTIME_IS_NUMERIC(itemTime)) {
        Float64 dt = CMTimeGetSeconds(CMTimeSubtract(itemTime, _lastItemTime));
        if (dt < -0.001 || dt > 0.50) _previousValid = NO;
    }
    _lastItemTime = itemTime;

    id<MTLTexture> yTexture = nil;
    id<MTLTexture> uvTexture = nil;
    id<MTLTexture> bgraTexture = nil;
    BOOL fullRange = NO;
    BOOL tenBit = NO;
    if (![self makeInputTexturesForPixelBuffer:pixelBuffer
                                      yTexture:&yTexture
                                     uvTexture:&uvTexture
                                   bgraTexture:&bgraTexture
                                     fullRange:&fullRange
                                        tenBit:&tenBit]) {
        self.lastFrameWasSupported = NO;
        return NO;
    }

    self.lastFrameWasSupported = YES;
    [self updateOutputColorSpaceForPixelBuffer:pixelBuffer];
    VFGPUUniforms uniforms = [self uniformsForPixelBuffer:pixelBuffer fullRange:fullRange tenBit:tenBit];

    CGSize layerSize = layer.bounds.size;
    CGFloat scale = UIScreen.mainScreen.scale;
    if (layer.contentsScale > 0.0) scale = layer.contentsScale;
    NSUInteger drawableW = (NSUInteger)MAX(1.0, floor(layerSize.width * scale));
    NSUInteger drawableH = (NSUInteger)MAX(1.0, floor(layerSize.height * scale));
    layer.drawableSize = CGSizeMake(drawableW, drawableH);
    if (dispatch_semaphore_wait(_inFlightSemaphore, DISPATCH_TIME_NOW) != 0) {
        // Drop a source frame rather than queueing unlimited GPU work or blocking UI.
        return NO;
    }

    id<CAMetalDrawable> drawable = [layer nextDrawable];
    if (!drawable) {
        dispatch_semaphore_signal(_inFlightSemaphore);
        return NO;
    }

    id<MTLCommandBuffer> cb = [_commandQueue commandBuffer];
    if (!cb) {
        dispatch_semaphore_signal(_inFlightSemaphore);
        return NO;
    }
    cb.label = @"VideoFilter frame";

    // Color decode: source -> A
    id<MTLComputeCommandEncoder> compute = [cb computeCommandEncoder];
    if (bgraTexture) {
        [compute setComputePipelineState:_bgraPipeline];
        [compute setTexture:bgraTexture atIndex:0];
        [compute setTexture:_textureA atIndex:1];
    } else {
        [compute setComputePipelineState:_yuvPipeline];
        [compute setTexture:yTexture atIndex:0];
        [compute setTexture:uvTexture atIndex:1];
        [compute setTexture:_textureA atIndex:2];
    }
    [compute setBytes:&uniforms length:sizeof(uniforms) atIndex:0];
    [self dispatchPipeline:(bgraTexture ? _bgraPipeline : _yuvPipeline)
                   encoder:compute width:width height:height];
    [compute endEncoding];

    // Exposure -> Contrast -> Saturation -> Highlights: A -> B
    compute = [cb computeCommandEncoder];
    [compute setComputePipelineState:_basicPipeline];
    [compute setTexture:_textureA atIndex:0];
    [compute setTexture:_textureB atIndex:1];
    [compute setBytes:&uniforms length:sizeof(uniforms) atIndex:0];
    [self dispatchPipeline:_basicPipeline encoder:compute width:width height:height];
    [compute endEncoding];

    id<MTLTexture> currentTexture = _textureB;

    // Sharpen is skipped entirely at zero to avoid unnecessary GPU work.
    if (uniforms.effectB.x > 0.0001f) {
        compute = [cb computeCommandEncoder];
        [compute setComputePipelineState:_sharpenPipeline];
        [compute setTexture:_textureB atIndex:0];
        [compute setTexture:_textureA atIndex:1];
        [compute setBytes:&uniforms length:sizeof(uniforms) atIndex:0];
        [self dispatchPipeline:_sharpenPipeline encoder:compute width:width height:height];
        [compute endEncoding];
        currentTexture = _textureA;
    }

    id<MTLTexture> presentationTexture = currentTexture;
    float motionBlend = uniforms.effectB.y;
    BOOL useMotionBlur = motionBlend > 0.0001f;

    id<MTLBuffer> sceneBuffer = nil;
    NSUInteger sceneSampleCount = 0;
    if (useMotionBlur && _previousValid) {
        // Reduced-grid scene-cut detection.  It runs asynchronously and never stalls the CPU.
        sceneBuffer = _sceneCutBuffers[_sceneCutBufferIndex++ % _sceneCutBuffers.count];
        id<MTLBlitCommandEncoder> clear = [cb blitCommandEncoder];
        [clear fillBuffer:sceneBuffer range:NSMakeRange(0, sizeof(uint32_t)) value:0];
        [clear endEncoding];

        compute = [cb computeCommandEncoder];
        [compute setComputePipelineState:_sceneCutPipeline];
        [compute setTexture:currentTexture atIndex:0];
        [compute setTexture:_previousTexture atIndex:1];
        [compute setBuffer:sceneBuffer offset:0 atIndex:0];
        NSUInteger sceneW = (width + 15) / 16;
        NSUInteger sceneH = (height + 15) / 16;
        sceneSampleCount = sceneW * sceneH;
        [self dispatchPipeline:_sceneCutPipeline encoder:compute width:sceneW height:sceneH];
        [compute endEncoding];

        id<MTLTexture> temporalOutput = (currentTexture == _textureA) ? _textureB : _textureA;
        compute = [cb computeCommandEncoder];
        [compute setComputePipelineState:_temporalPipeline];
        [compute setTexture:currentTexture atIndex:0];
        [compute setTexture:_previousTexture atIndex:1];
        [compute setTexture:temporalOutput atIndex:2];
        [compute setBytes:&uniforms length:sizeof(uniforms) atIndex:0];
        [self dispatchPipeline:_temporalPipeline encoder:compute width:width height:height];
        [compute endEncoding];
        presentationTexture = temporalOutput;
    }

    // Keep the unblurred current frame as history so 6% remains an actual 94/6 blend,
    // rather than accumulating a long exponential trail.
    if (useMotionBlur) {
        id<MTLBlitCommandEncoder> copy = [cb blitCommandEncoder];
        [copy copyFromTexture:currentTexture
                  sourceSlice:0
                  sourceLevel:0
                 sourceOrigin:MTLOriginMake(0, 0, 0)
                   sourceSize:MTLSizeMake(width, height, 1)
                    toTexture:_previousTexture
             destinationSlice:0
             destinationLevel:0
            destinationOrigin:MTLOriginMake(0, 0, 0)];
        [copy endEncoding];
        _previousValid = YES;
    } else {
        _previousValid = NO;
    }

    [self encodePresentTexture:presentationTexture commandBuffer:cb drawable:drawable];
    [cb presentDrawable:drawable];

    if (sceneBuffer && sceneSampleCount > 0) {
        __weak FilterEngine *weakSelf = self;
        [cb addCompletedHandler:^(id<MTLCommandBuffer> finished) {
            (void)finished;
            FilterEngine *strongSelf = weakSelf;
            if (!strongSelf || strongSelf->_invalidated.load()) return;
            uint32_t changed = *(volatile uint32_t *)sceneBuffer.contents;
            float ratio = (float)changed / (float)sceneSampleCount;
            if (ratio > 0.46f) strongSelf->_sceneCutPending.store(true);
        }];
    }

    dispatch_semaphore_t inFlight = _inFlightSemaphore;
    [cb addCompletedHandler:^(__unused id<MTLCommandBuffer> finished) {
        dispatch_semaphore_signal(inFlight);
    }];

#if DEBUG
    _debugFrameCount++;
    CFTimeInterval now = CACurrentMediaTime();
    if (now - _debugWindowStart >= 2.0) {
        double fps = (double)_debugFrameCount / (now - _debugWindowStart);
        NSLog(@"[VideoFilter] submitted %.1f filtered frames/s (%lux%lu)", fps,
              (unsigned long)width, (unsigned long)height);
        _debugWindowStart = now;
        _debugFrameCount = 0;
    }
#endif

    [cb commit];
    return YES;
}

@end
