#pragma once
#import "MenuItem.h"

NS_ASSUME_NONNULL_BEGIN

typedef void (^VFSliderChangedBlock)(float value);

@interface VFSliderItem : VFMenuItem
@property (nonatomic, readonly) float value;
- (instancetype)initWithTitle:(NSString *)title
                      minimum:(float)minimum
                      maximum:(float)maximum
                 initialValue:(float)initialValue
                      percent:(BOOL)percent
                     onChange:(VFSliderChangedBlock)onChange;
- (void)setValue:(float)value animated:(BOOL)animated notify:(BOOL)notify;
@end

NS_ASSUME_NONNULL_END
