# Build fixes

Fixes applied after the first GitHub Actions compile log:

1. `Menu.mm`: replace `__weak typeof(self)` with an explicit `__weak VFMenu *` capture so Objective-C++ parsing succeeds under the selected Theos toolchain.
2. `Menu.mm`: fix the RESET helper call from the nonexistent `VFFilterSettingsZeroed` to the existing `VFFilterZeroed` helper.
3. `scripts/embed_shaders.py`: shorten the C++ raw-string delimiter to `VFMS6F1A` (C++ raw-string delimiters are limited to 16 characters).
4. Regenerate `ShadersEmbedded.inc` with the corrected delimiter.

No filter values, UI controls, Bundle IDs, or functional requirements were changed.
