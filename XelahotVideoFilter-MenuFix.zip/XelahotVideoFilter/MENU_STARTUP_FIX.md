Menu startup fix:
- Removed the redundant exact Bundle-ID gate from Tweak.xm. VideoFilter.plist still carries the selected injection targets.
- Starts VFMenu before VideoHook.
- Retries UIWindowScene acquisition for up to ~6 seconds if injection occurs before the scene is ready.
- Keeps the same four configured bundle IDs in TargetApps.plist / VideoFilter.plist.
