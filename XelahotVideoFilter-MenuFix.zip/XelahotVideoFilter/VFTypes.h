#pragma once

#import <Foundation/Foundation.h>
#import <CoreMedia/CoreMedia.h>
#include <math.h>

NS_ASSUME_NONNULL_BEGIN

typedef struct {
    BOOL enabled;
    float contrast;      // UI: -100 ... +100
    float saturation;    // UI: -100 ... +100
    float exposure;      // UI: -100 ... +100
    float sharpen;       // UI:    0 ... 100
    float highlights;    // UI: -100 ... +100
    float motionBlur;    // UI:    0 ... 20 (% previous frame)
} VFFilterSettings;

static inline VFFilterSettings VFFilterSettingsMake(BOOL enabled,
                                                     float contrast,
                                                     float saturation,
                                                     float exposure,
                                                     float sharpen,
                                                     float highlights,
                                                     float motionBlur) {
    VFFilterSettings s;
    s.enabled = enabled;
    s.contrast = contrast;
    s.saturation = saturation;
    s.exposure = exposure;
    s.sharpen = sharpen;
    s.highlights = highlights;
    s.motionBlur = motionBlur;
    return s;
}

static inline VFFilterSettings VFFilterPresetDefaults(void) {
    return VFFilterSettingsMake(NO, 15.0f, 5.0f, 5.0f, 40.0f, 5.0f, 6.0f);
}

static inline VFFilterSettings VFFilterZeroed(BOOL enabled) {
    return VFFilterSettingsMake(enabled, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f);
}

static inline BOOL VFFilterSettingsHasVisibleEffect(VFFilterSettings s) {
    const float eps = 0.0001f;
    return s.enabled &&
        (fabsf(s.contrast) > eps || fabsf(s.saturation) > eps ||
         fabsf(s.exposure) > eps || fabsf(s.sharpen) > eps ||
         fabsf(s.highlights) > eps || fabsf(s.motionBlur) > eps);
}

NS_ASSUME_NONNULL_END
