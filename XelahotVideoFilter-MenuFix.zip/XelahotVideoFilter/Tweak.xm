#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "Menu.h"
#import "VideoHook.h"

%ctor {
    @autoreleasepool {
        // The injection filter (VideoFilter.plist) decides which apps load this tweak.
        // Do not repeat an exact Bundle ID check here: re-signed apps can have a
        // modified bundle identifier even though this dylib was intentionally injected.
        dispatch_async(dispatch_get_main_queue(), ^{
            // Bring up the overlay first so a video-renderer incompatibility cannot
            // prevent the menu from appearing.
            [[VFMenu sharedInstance] start];
            [[VideoHook sharedInstance] start];
        });
    }
}
