#pragma once
#import "MenuItem.h"

NS_ASSUME_NONNULL_BEGIN

typedef void (^VFToggleChangedBlock)(BOOL enabled);

@interface VFToggleItem : VFMenuItem
@property (nonatomic, readonly, getter=isOn) BOOL on;
- (instancetype)initWithTitle:(NSString *)title
                     initialOn:(BOOL)initialOn
                      onChange:(VFToggleChangedBlock)onChange;
- (void)setOn:(BOOL)on animated:(BOOL)animated;
@end

NS_ASSUME_NONNULL_END
