#pragma once
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface VFPage : UIView
- (instancetype)initWithItems:(NSArray<UIView *> *)items;
@end

NS_ASSUME_NONNULL_END
