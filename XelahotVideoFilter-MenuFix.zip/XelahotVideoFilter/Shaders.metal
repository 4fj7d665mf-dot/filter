#include <metal_stdlib>
using namespace metal;

struct VFUniforms {
    // effectA: exposureStops, contrastFactor, saturationFactor, highlightStrength
    float4 effectA;
    // effectB: sharpenAmount, motionBlend, invWidth, invHeight
    float4 effectB;
    // yuvRange: yOffset, yScale, chromaOffset, chromaScale
    float4 yuvRange;
    // meta: matrix (0=601,1=709,2=2020), transfer (0=709,1=sRGB,2=PQ,3=HLG,4=linear), hdr, reserved
    uint4 meta;
};

struct VFPresentUniforms {
    // x = video aspect, y = drawable aspect, z = gravity (0 resize, 1 aspect, 2 aspectFill)
    float4 params;
};

static inline float vf709ToLinear(float x) {
    x = max(x, 0.0f);
    return x < 0.081f ? x / 4.5f : pow((x + 0.099f) / 1.099f, 1.0f / 0.45f);
}

static inline float vfsRGBToLinear(float x) {
    x = max(x, 0.0f);
    return x <= 0.04045f ? x / 12.92f : pow((x + 0.055f) / 1.055f, 2.4f);
}

static inline float vfPQToEDR(float x) {
    // ST.2084 EOTF. Return EDR units where 1.0 ~= 100 nits and 100 ~= 10,000 nits.
    const float m1 = 0.1593017578125f;
    const float m2 = 78.84375f;
    const float c1 = 0.8359375f;
    const float c2 = 18.8515625f;
    const float c3 = 18.6875f;
    float p = pow(clamp(x, 0.0f, 1.0f), 1.0f / m2);
    float n = max(p - c1, 0.0f);
    float d = max(c2 - c3 * p, 1e-6f);
    float normalized10000Nits = pow(n / d, 1.0f / m1);
    return normalized10000Nits * 100.0f;
}

static inline float vfHLGToEDR(float x) {
    // ITU-R BT.2100 HLG inverse OETF. Approximate a 1000-nit display mapping.
    const float a = 0.17883277f;
    const float b = 0.28466892f;
    const float c = 0.55991073f;
    x = max(x, 0.0f);
    float scene = x <= 0.5f ? (x * x) / 3.0f : (exp((x - c) / a) + b) / 12.0f;
    return scene * 10.0f;
}

static inline float3 vfDecodeTransfer(float3 v, uint transfer) {
    if (transfer == 1u) {
        return float3(vfsRGBToLinear(v.r), vfsRGBToLinear(v.g), vfsRGBToLinear(v.b));
    }
    if (transfer == 2u) {
        return float3(vfPQToEDR(v.r), vfPQToEDR(v.g), vfPQToEDR(v.b));
    }
    if (transfer == 3u) {
        return float3(vfHLGToEDR(v.r), vfHLGToEDR(v.g), vfHLGToEDR(v.b));
    }
    if (transfer == 4u) return max(v, 0.0f);
    return float3(vf709ToLinear(v.r), vf709ToLinear(v.g), vf709ToLinear(v.b));
}

static inline float3 vfYUVToRGB(float y, float cb, float cr, uint matrix) {
    if (matrix == 0u) {
        return float3(y + 1.402000f * cr,
                      y - 0.344136f * cb - 0.714136f * cr,
                      y + 1.772000f * cb);
    }
    if (matrix == 2u) {
        return float3(y + 1.474600f * cr,
                      y - 0.164553f * cb - 0.571353f * cr,
                      y + 1.881400f * cb);
    }
    return float3(y + 1.574800f * cr,
                  y - 0.187324f * cb - 0.468124f * cr,
                  y + 1.855600f * cb);
}

kernel void vfYUVToLinear(texture2d<float, access::sample> yTexture [[texture(0)]],
                          texture2d<float, access::sample> uvTexture [[texture(1)]],
                          texture2d<half, access::write> output [[texture(2)]],
                          constant VFUniforms &u [[buffer(0)]],
                          uint2 gid [[thread_position_in_grid]]) {
    if (gid.x >= output.get_width() || gid.y >= output.get_height()) return;
    constexpr sampler s(coord::normalized, address::clamp_to_edge, filter::linear);
    float2 uv = (float2(gid) + 0.5f) / float2(output.get_width(), output.get_height());
    float yRaw = yTexture.sample(s, uv).r;
    float2 cRaw = uvTexture.sample(s, uv).rg;
    float y = (yRaw - u.yuvRange.x) * u.yuvRange.y;
    float cb = (cRaw.x - u.yuvRange.z) * u.yuvRange.w;
    float cr = (cRaw.y - u.yuvRange.z) * u.yuvRange.w;
    float3 rgbPrime = max(vfYUVToRGB(y, cb, cr, u.meta.x), 0.0f);
    float3 linearRGB = vfDecodeTransfer(rgbPrime, u.meta.y);
    output.write(half4(half3(linearRGB), half(1.0)), gid);
}

kernel void vfBGRAToLinear(texture2d<float, access::read> input [[texture(0)]],
                           texture2d<half, access::write> output [[texture(1)]],
                           constant VFUniforms &u [[buffer(0)]],
                           uint2 gid [[thread_position_in_grid]]) {
    if (gid.x >= output.get_width() || gid.y >= output.get_height()) return;
    float3 rgbPrime = max(input.read(gid).rgb, 0.0f);
    float3 linearRGB = vfDecodeTransfer(rgbPrime, u.meta.y);
    output.write(half4(half3(linearRGB), half(1.0)), gid);
}

static inline float vfLuma(float3 c) {
    return dot(c, float3(0.2126f, 0.7152f, 0.0722f));
}

static inline float vfSoftShoulderScalar(float x, float maxHeadroom) {
    x = max(x, 0.0f);
    if (x <= 1.0f) return x;
    float over = x - 1.0f;
    float compressed = over / (1.0f + over / max(maxHeadroom, 0.1f));
    return 1.0f + compressed;
}

static inline float3 vfSoftShoulder(float3 c, bool hdr) {
    float headroom = hdr ? 24.0f : 0.65f;
    return float3(vfSoftShoulderScalar(c.r, headroom),
                  vfSoftShoulderScalar(c.g, headroom),
                  vfSoftShoulderScalar(c.b, headroom));
}

kernel void vfBasicAdjust(texture2d<half, access::read> input [[texture(0)]],
                          texture2d<half, access::write> output [[texture(1)]],
                          constant VFUniforms &u [[buffer(0)]],
                          uint2 gid [[thread_position_in_grid]]) {
    if (gid.x >= output.get_width() || gid.y >= output.get_height()) return;
    float3 c = float3(input.read(gid).rgb);

    // 1) Exposure: UI value has already been mapped to photographic stops on CPU.
    c *= exp2(u.effectA.x);

    // 2) Contrast around a linear-light middle-gray pivot.
    const float pivot = 0.18f;
    c = (c - pivot) * u.effectA.y + pivot;
    c = max(c, 0.0f);

    // 3) Saturation using luminance, not a per-channel multiplier.
    float y = vfLuma(c);
    c = y + (c - y) * u.effectA.z;
    c = max(c, 0.0f);

    // 4) Highlights: affect mostly brighter regions, with a smooth mask.
    y = vfLuma(c);
    float hmask = smoothstep(0.48f, 1.10f, y);
    c *= (1.0f + u.effectA.w * hmask);
    c = vfSoftShoulder(c, u.meta.z != 0u);

    output.write(half4(half3(c), half(1.0)), gid);
}

kernel void vfSharpen(texture2d<half, access::read> input [[texture(0)]],
                      texture2d<half, access::write> output [[texture(1)]],
                      constant VFUniforms &u [[buffer(0)]],
                      uint2 gid [[thread_position_in_grid]]) {
    uint w = output.get_width();
    uint h = output.get_height();
    if (gid.x >= w || gid.y >= h) return;

    int2 p = int2(gid);
    int2 maxP = int2(int(w) - 1, int(h) - 1);
    uint2 pc  = uint2(clamp(p,               int2(0), maxP));
    uint2 pn  = uint2(clamp(p + int2(0,-1), int2(0), maxP));
    uint2 ps  = uint2(clamp(p + int2(0, 1), int2(0), maxP));
    uint2 pe  = uint2(clamp(p + int2(1, 0), int2(0), maxP));
    uint2 pw  = uint2(clamp(p + int2(-1,0), int2(0), maxP));
    uint2 pne = uint2(clamp(p + int2(1,-1), int2(0), maxP));
    uint2 pnw = uint2(clamp(p + int2(-1,-1),int2(0), maxP));
    uint2 pse = uint2(clamp(p + int2(1, 1), int2(0), maxP));
    uint2 psw = uint2(clamp(p + int2(-1,1), int2(0), maxP));

    float3 center = float3(input.read(pc).rgb);
    float3 n = float3(input.read(pn).rgb);
    float3 s = float3(input.read(ps).rgb);
    float3 e = float3(input.read(pe).rgb);
    float3 wv = float3(input.read(pw).rgb);
    float3 ne = float3(input.read(pne).rgb);
    float3 nw = float3(input.read(pnw).rgb);
    float3 se = float3(input.read(pse).rgb);
    float3 sw = float3(input.read(psw).rgb);
    float3 blur = (n + s + e + wv) * 0.15f + (ne + nw + se + sw) * 0.10f;

    float3 detail = center - blur;
    float detailLuma = abs(vfLuma(detail));
    float noiseGate = smoothstep(0.0015f, 0.012f, detailLuma);
    detail *= noiseGate;

    // Limit high-frequency gain to reduce white halos and ringing.
    detail = clamp(detail, float3(-0.075f), float3(0.075f));
    float3 candidate = center + detail * u.effectB.x;

    float3 localMin = min(center, min(min(n, s), min(e, wv)));
    float3 localMax = max(center, max(max(n, s), max(e, wv)));
    float margin = 0.018f + vfLuma(center) * 0.010f;
    candidate = clamp(candidate, max(localMin - margin, 0.0f), localMax + margin);

    output.write(half4(half3(candidate), half(1.0)), gid);
}

kernel void vfTemporalBlend(texture2d<half, access::read> currentFrame [[texture(0)]],
                            texture2d<half, access::read> previousFrame [[texture(1)]],
                            texture2d<half, access::write> output [[texture(2)]],
                            constant VFUniforms &u [[buffer(0)]],
                            uint2 gid [[thread_position_in_grid]]) {
    if (gid.x >= output.get_width() || gid.y >= output.get_height()) return;
    float3 current = float3(currentFrame.read(gid).rgb);
    float3 previous = float3(previousFrame.read(gid).rgb);

    float lc = vfLuma(current);
    float lp = vfLuma(previous);
    float normalizedDelta = abs(lc - lp) / max(0.16f, lc + 0.08f);
    float sceneGate = 1.0f - smoothstep(0.07f, 0.24f, normalizedDelta);
    float blendAmount = clamp(u.effectB.y * sceneGate, 0.0f, 0.20f);
    float3 result = mix(current, previous, blendAmount);
    output.write(half4(half3(result), half(1.0)), gid);
}

kernel void vfSceneCutDetect(texture2d<half, access::read> currentFrame [[texture(0)]],
                             texture2d<half, access::read> previousFrame [[texture(1)]],
                             device atomic_uint *changedSamples [[buffer(0)]],
                             uint2 gid [[thread_position_in_grid]]) {
    uint2 p = gid * 16u + 8u;
    if (p.x >= currentFrame.get_width() || p.y >= currentFrame.get_height()) return;
    float3 c = float3(currentFrame.read(p).rgb);
    float3 prev = float3(previousFrame.read(p).rgb);
    float lc = vfLuma(c);
    float lp = vfLuma(prev);
    float delta = abs(lc - lp) / max(0.18f, lc + 0.10f);
    if (delta > 0.32f) {
        atomic_fetch_add_explicit(changedSamples, 1u, memory_order_relaxed);
    }
}

struct VFVertexOut {
    float4 position [[position]];
    float2 uv;
};

vertex VFVertexOut vfPresentVertex(uint vertexID [[vertex_id]]) {
    const float2 positions[3] = {
        float2(-1.0f, -1.0f),
        float2( 3.0f, -1.0f),
        float2(-1.0f,  3.0f)
    };
    const float2 uvs[3] = {
        float2(0.0f, 1.0f),
        float2(2.0f, 1.0f),
        float2(0.0f, -1.0f)
    };
    VFVertexOut out;
    out.position = float4(positions[vertexID], 0.0f, 1.0f);
    out.uv = uvs[vertexID];
    return out;
}

fragment half4 vfPresentFragment(VFVertexOut in [[stage_in]],
                                 texture2d<half, access::sample> source [[texture(0)]],
                                 constant VFPresentUniforms &u [[buffer(0)]]) {
    constexpr sampler s(coord::normalized, address::clamp_to_edge, filter::linear);
    float2 uv = in.uv;
    float videoAspect = max(u.params.x, 0.001f);
    float drawAspect = max(u.params.y, 0.001f);
    uint gravity = uint(u.params.z + 0.5f);

    if (gravity == 1u) { // resizeAspect
        if (videoAspect > drawAspect) {
            float displayedHeight = drawAspect / videoAspect;
            float y0 = (1.0f - displayedHeight) * 0.5f;
            if (uv.y < y0 || uv.y > y0 + displayedHeight) return half4(0.0h, 0.0h, 0.0h, 0.0h);
            uv.y = (uv.y - y0) / displayedHeight;
        } else {
            float displayedWidth = videoAspect / drawAspect;
            float x0 = (1.0f - displayedWidth) * 0.5f;
            if (uv.x < x0 || uv.x > x0 + displayedWidth) return half4(0.0h, 0.0h, 0.0h, 0.0h);
            uv.x = (uv.x - x0) / displayedWidth;
        }
    } else if (gravity == 2u) { // resizeAspectFill
        if (videoAspect > drawAspect) {
            float sourceWidth = drawAspect / videoAspect;
            uv.x = 0.5f + (uv.x - 0.5f) * sourceWidth;
        } else {
            float sourceHeight = videoAspect / drawAspect;
            uv.y = 0.5f + (uv.y - 0.5f) * sourceHeight;
        }
    }

    half4 c = source.sample(s, clamp(uv, 0.0f, 1.0f));
    c.a = 1.0h;
    return c;
}
