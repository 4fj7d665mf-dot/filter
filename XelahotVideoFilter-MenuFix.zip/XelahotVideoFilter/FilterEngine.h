#pragma once

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>
#import <CoreVideo/CoreVideo.h>
#import <Metal/Metal.h>
#import <QuartzCore/CAMetalLayer.h>
#import "VFTypes.h"

NS_ASSUME_NONNULL_BEGIN

@interface FilterEngine : NSObject
@property (nonatomic, readonly) id<MTLDevice> device;
@property (nonatomic) VFFilterSettings settings;
@property (nonatomic, copy) AVLayerVideoGravity videoGravity;
@property (nonatomic, readonly) BOOL lastFrameWasSupported;

- (instancetype)initWithMetalLayer:(CAMetalLayer *)metalLayer NS_DESIGNATED_INITIALIZER;
- (instancetype)init NS_UNAVAILABLE;

- (BOOL)renderPixelBuffer:(CVPixelBufferRef)pixelBuffer
                 itemTime:(CMTime)itemTime;
- (void)resetTemporalHistory;
- (void)purgeReusableResources;
@end

NS_ASSUME_NONNULL_END
