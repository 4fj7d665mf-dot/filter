#import "MenuItem.h"

@implementation VFMenuItem {
    UILabel *_titleLabel;
}

- (instancetype)initWithTitle:(NSString *)title {
    self = [super initWithFrame:CGRectZero];
    if (!self) return nil;

    self.translatesAutoresizingMaskIntoConstraints = NO;
    _titleLabel = [UILabel new];
    _titleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    _titleLabel.text = title;
    _titleLabel.textColor = UIColor.whiteColor;
    _titleLabel.font = [UIFont systemFontOfSize:12.5 weight:UIFontWeightMedium];
    [self addSubview:_titleLabel];
    return self;
}

- (UILabel *)titleLabel { return _titleLabel; }

@end
